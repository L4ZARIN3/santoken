<?php

declare(strict_types=1);
/**
 * This file is part of Hyperf.
 *
 * @link     https://www.hyperf.io
 * @document https://hyperf.wiki
 * @contact  group@hyperf.io
 * @license  https://github.com/hyperf/hyperf/blob/master/LICENSE
 */
namespace Lazarini\HyperfSantoken;

class ConfigProvider
{
    public function __invoke(): array
    {
        return [
            'dependencies' => [
            ],
            'commands' => [
            ],
            'annotations' => [
                'scan' => [
                    'paths' => [
                        __DIR__,
                    ],
                ],
            ],
            'publish' => [
                [
                    'id' => 'config',
                    'description' => 'The configuration file for Hyperf Auth.',
                    'source' => __DIR__ . '/../publish/config/santoken.php',
                    'destination' => BASE_PATH . '/config/autoload/santoken.php',
                ],
                [
                    'id' => 'migrations',
                    'description' => 'The migration file for creating auth tokens table.',
                    'source' => __DIR__ . '/../publish/Migrations/2025_02_07_000000_create_auth_tokens_table.php',
                    'destination' => BASE_PATH . '/migrations/2025_02_07_000000_create_auth_tokens_table.php',
                ],
                [
                    'id' => 'helpers',
                    'description' => 'helper para autenticação.',
                    'source' => __DIR__ . '/../publish/Helper/SanTokenHelper.php',
                    'destination' => BASE_PATH . '/app/Helper/SanTokenHelper.php',
                ],
                [
                    'id' => 'middleware',
                    'description' => 'helper para autenticação.',
                    'source' => __DIR__ . '/../publish/Middleware/SanTokenAuthMiddleware.php',
                    'destination' => BASE_PATH . '/app/Middleware/SanTokenAuthMiddleware.php',
                ],
            ],
        ];
    }
}
